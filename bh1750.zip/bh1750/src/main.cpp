/*
  Example of BH1750 library usage. This example initialises the BH1750 object using the default high resolution continuous mode and then makes a light level reading every second.
*/

#include <Wire.h>
#include <BH1750.h>
#include <DHT.h>
#include <DHT_U.h>
#include <Adafruit_Sensor.h>


#define DHTTYPE DHT11
#define DHTPIN 7


BH1750 lightMeter;

DHT_Unified dht(DHTPIN, DHTTYPE);

void setup(){
  Serial.begin(9600);

  // Initialize the I2C bus (BH1750 library doesn't do this automatically)
  Wire.begin();
  // On esp8266 you can select SCL and SDA pins using Wire.begin(D4, D3);
  // For Wemos / Lolin D1 Mini Pro and the Ambient Light shield use Wire.begin(D2, D1);

  lightMeter.begin();
  dht.begin();
}

void loop() {
  float lux = lightMeter.readLightLevel();
  Serial.print("lux:" );
  Serial.println(lux);
  delay(1000);
  sensors_event_t event;
  dht.temperature().getEvent(&event);
  if (isnan(event.temperature)) {
    Serial.println(F("Error reading temperature!"));
  }
  else {
    Serial.print(F("C:"));
    Serial.println(event.temperature);
  }
}